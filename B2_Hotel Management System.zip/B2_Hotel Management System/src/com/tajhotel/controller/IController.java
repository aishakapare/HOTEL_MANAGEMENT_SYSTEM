package com.tajhotel.controller;

public interface IController {
    public void insert();
    public void select();
} 
