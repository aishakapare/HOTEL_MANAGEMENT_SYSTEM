package com.tajhotel.service;

import com.tajhotel.dao.Customer;

public interface IService {
    public int insert(Customer customer);
    public Customer select(int id);
}
