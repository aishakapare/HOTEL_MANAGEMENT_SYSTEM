package com.tajhotel.controller;

import java.util.Scanner;

import com.tajhotel.dao.Customer;
import com.tajhotel.service.ServiceImpl;
import com.tajhotel.service.IService;

public class ControllerImpl implements IController {
	Scanner sc= new Scanner(System.in);
    IService service = new ServiceImpl();

	
	public void insert() {
        
        System.out.print("ID :: ");
        int id = sc.nextInt();
        
        System.out.print("Name :: ");
        String name = sc.next();
        
        System.out.print("Age :: ");
        int age = sc.nextInt();
        
        System.out.print("City :: ");
        String city = sc.next();
        
        System.out.print("Status :: ");
        String status = sc.next();
        
        Customer c1 = new Customer();
        c1.setId(id);
        c1.setName(name);
        c1.setAge(age);
        c1.setCity(city);
        c1.setStatus(status);
        
        
      int rowAffect = service.insert(c1);
        
      if(rowAffect != 0) {
    	  System.out.println("Data Inserted Sucessfully");
      }else {
    	  System.out.println("Data Insertion Failed");
      }
        
	}
	
	public void select() {
		System.out.print("Enter ID :: ");  
		int id = sc.nextInt();
		
		Customer c1 = service.select(id);
		
		if(c1 != null) {
		//	System.out.println(c1);
		System.out.println("ID\tNAME\tAGE\tCITY\tSTATUS");
		System.out.println(c1.getId()+"\t"+c1.getName()+"\t"+c1.getAge()+"\t"+c1.getCity()+"\t"+c1.getStatus());
		}
		else {
			System.out.println("Record not Found");
		}
		
		
	}

}
