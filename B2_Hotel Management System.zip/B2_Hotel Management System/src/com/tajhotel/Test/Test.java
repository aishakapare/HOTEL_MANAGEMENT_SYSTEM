package com.tajhotel.Test;

import java.util.Scanner;

import com.tajhotel.controller.ControllerImpl;
import com.tajhotel.controller.IController;

public class Test {

	public static void main(String[] args) {
          Test.start();
	}
	
	public static void start() {
		System.out.println("************Welcome to Taj Hotel****************");
		IController controller = new ControllerImpl();
		
		while(true) {
	    System.out.println("************************************************");
		System.out.println("1. Insert Customer Record\n2. Update Customer Record\n3. Delete Customer Record\n4. View Customer Record\n5. Exit");
		System.out.println("************************************************");
	
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your Choise :: ");
		int x = sc.nextInt();
		
		
		switch(x) {
		case 1: controller.insert();
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:controller.select();
			break;
		case 5:  System.out.println("Thank you for using our application");
			     System.exit(0);
			break;
		    default:System.out.println("Invalid input Please Try Again !!!");
		}
		System.out.println("************************************************\n");
  
		}
		
		
	
	}

}
