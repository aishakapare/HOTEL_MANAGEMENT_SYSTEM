package com.tajhotel.persistance;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tajhotel.dao.Customer;
import com.tajhotel.util.JdbcUtil;

public class PersistanceImpl implements IPersistance {

	@Override
	public int insert(Customer customer) {
        Connection connection = null;
        PreparedStatement pstmt = null;
        
        String insertSQLQuery = "Insert into customer values(?,?,?,?,?)";
        int rowAffect = 0;
        try {
			connection = JdbcUtil.getConnection();
			
			if(connection != null) {
				pstmt = connection.prepareStatement(insertSQLQuery);
			}
			
			if(pstmt != null) {
				pstmt.setInt(1, customer.getId());
				pstmt.setString(2, customer.getName());
				pstmt.setInt(3, customer.getAge());
				pstmt.setString(4, customer.getCity());
				pstmt.setString(5, customer.getStatus());
				
				 rowAffect = pstmt.executeUpdate();
				 return rowAffect;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}
        
        finally {
        	try {
				JdbcUtil.cleanUp(connection, pstmt, null);
			} catch (SQLException e) {
				e.printStackTrace();
			}
        	
        }
        return rowAffect;
        
	}
	
	public Customer select(int id) {
		    Connection connection = null;
	        PreparedStatement pstmt = null;
	        ResultSet resultSet = null;
	        Customer c1 = null;
	        String selectSQLQuery = "Select * From Customer Where id = ?";
	      
	        try {
				connection = JdbcUtil.getConnection();
				
				if(connection != null) {
					pstmt = connection.prepareStatement(selectSQLQuery);
				}
				
				if(pstmt != null) {
					pstmt.setInt(1, id);
				
					
					resultSet=pstmt.executeQuery();
					
				}
				
				if(resultSet != null) {
					 c1 = new Customer();
					while(resultSet.next()) {
						c1.setId(resultSet.getInt(1));
						c1.setName(resultSet.getString(2));
						c1.setAge(resultSet.getInt(3));
						c1.setCity(resultSet.getString(4));
						c1.setStatus(resultSet.getString(5));
					}
					
					return c1;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch(Exception e) {
				e.printStackTrace();
			}
	        
	        finally {
	        	try {
					JdbcUtil.cleanUp(connection, pstmt, null);
				} catch (SQLException e) {
					e.printStackTrace();
				}
	        	
	        }
	       return c1;
	        
	}

}
